chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'activatePopup') {
        // Open the popup programmatically when the content script detects a matching URL
        chrome.action.openPopup();
    }

    if (message.action === 'submitProperty') {
        // Use the chrome.tabs API to get the active tab URL
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            const activeTab = tabs[0];
            const url = activeTab?.url || '';

            if (!url) {
                console.error('URL is missing');
                sendResponse({ success: false, message: 'Failed to submit property: Missing URL.' });
                return;
            }

            // Authenticate and fetch user's email using OAuth2
            chrome.identity.getAuthToken({ interactive: true }, function (token) {
                if (chrome.runtime.lastError || !token) {
                    console.error('Authentication error:', chrome.runtime.lastError || 'No token retrieved');
                    // Remove cached token and retry authentication
                    chrome.identity.removeCachedAuthToken({ token }, function () {
                        chrome.identity.getAuthToken({ interactive: true }, function (newToken) {
                            if (chrome.runtime.lastError || !newToken) {
                                console.error('Authentication retry failed:', chrome.runtime.lastError || 'No token retrieved');
                                sendResponse({ success: false, message: 'Failed to authenticate user.' });
                                chrome.tabs.sendMessage(sender.tab.id, { action: 'showStatus', text: 'Failed to authenticate user.', type: 'error' });
                                return;
                            }
                            token = newToken; // Use the refreshed token for the next steps
                            proceedWithPropertySubmission(url, token, sender, sendResponse);
                        });
                    });
                    return;
                }
                proceedWithPropertySubmission(url, token, sender, sendResponse);
            });

            return true;
        });
    }
});

// Configuration - Replace with your actual Google Sheets ID
const GOOGLE_SHEETS_CONFIG = {
    spreadsheetId: '1baVsy9030NI12qzDes22gwWLjfzP7RA0dyrnNoGp1K0', // Replace with your Google Sheets ID
    range: 'Sheet1!A:C', // Adjust range as needed
    sheetName: 'Sheet1'
};

// Google Sheets API integration
async function submitToGoogleSheets(url, contact, token) {
    try {
        const timestamp = new Date().toISOString();
        
        // First, get the sheet to determine the next row
        const getResponse = await fetch(
            `https://sheets.googleapis.com/v4/spreadsheets/${GOOGLE_SHEETS_CONFIG.spreadsheetId}/values/${GOOGLE_SHEETS_CONFIG.range}`,
            {
                headers: {
                    'Authorization': 'Bearer ' + token
                }
            }
        );
        
        const getResult = await getResponse.json();
        const nextRow = (getResult.values ? getResult.values.length : 0) + 1;
        
        // Append new row with property data
        const appendResponse = await fetch(
            `https://sheets.googleapis.com/v4/spreadsheets/${GOOGLE_SHEETS_CONFIG.spreadsheetId}/values/${GOOGLE_SHEETS_CONFIG.sheetName}!A${nextRow}:C${nextRow}?valueInputOption=USER_ENTERED`,
            {
                method: 'PUT',
                headers: {
                    'Authorization': 'Bearer ' + token,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    values: [[timestamp, contact, url]]
                })
            }
        );
        
        if (!appendResponse.ok) {
            throw new Error(`Sheets API error: ${appendResponse.status}`);
        }
        
        const result = await appendResponse.json();
        console.log('Successfully added to Google Sheets:', result);
        return { success: true, result };
        
    } catch (error) {
        console.error('Error submitting to Google Sheets:', error);
        return { success: false, error: error.message };
    }
}

// Helper function to generate status messages based on submission results
function getSubmissionStatusMessage(firebaseSuccess, sheetsSuccess) {
    if (firebaseSuccess && sheetsSuccess) {
        return 'Link submitted successfully to both Firebase and Google Sheets!';
    } else if (firebaseSuccess) {
        return 'Link submitted to Firebase successfully (Google Sheets failed)';
    } else if (sheetsSuccess) {
        return 'Link submitted to Google Sheets successfully (Firebase failed)';
    } else {
        return 'Failed to submit Link to both services';
    }
}

function proceedWithPropertySubmission(url, token, sender, sendResponse) {
    fetch('https://www.googleapis.com/oauth2/v2/userinfo?alt=json', {
        headers: {
            'Authorization': 'Bearer ' + token
        }
    })
    .then(response => response.json())
    .then(userInfo => {
        const contact = userInfo?.email || '';

        if (!contact) {
            console.error('Contact (email) is missing');
            sendResponse({ success: false, message: 'Failed to submit property: Missing contact info.' });
            return;
        }

        // Submit to both Firebase and Google Sheets in parallel
        Promise.allSettled([
            // Firebase submission
            fetch('https://us-central1-sightonscene-a87ca.cloudfunctions.net/submitProperty', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + token
                },
                body: JSON.stringify({ url, contact })
            }).then(response => response.json()),
            
            // Google Sheets submission
            submitToGoogleSheets(url, contact, token)
        ])
        .then(results => {
            const [firebaseResult, sheetsResult] = results;
            
            console.log('Firebase result:', firebaseResult);
            console.log('Google Sheets result:', sheetsResult);
            
            // Check if at least one submission succeeded
            const firebaseSuccess = firebaseResult.status === 'fulfilled';
            const sheetsSuccess = sheetsResult.status === 'fulfilled' && sheetsResult.value.success;
            
            if (firebaseSuccess || sheetsSuccess) {
                console.log('Property submitted to at least one service');
                
                // Send usage email only if Firebase succeeded (keeping original behavior)
                if (firebaseSuccess) {
                    fetch('https://us-central1-sightonscene-a87ca.cloudfunctions.net/sendUsageEmails', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': 'Bearer ' + token
                        },
                        body: JSON.stringify({ userEmail: contact, url })
                    })
                    .then(emailResponse => emailResponse.json())
                    .then(emailData => {
                        console.log('Email sent:', emailData);
                        const statusMessage = getSubmissionStatusMessage(firebaseSuccess, sheetsSuccess);
                        sendResponse({ success: true, message: statusMessage });
                        chrome.tabs.sendMessage(sender.tab.id, { action: 'showStatus', text: statusMessage, type: 'success' });
                    })
                    .catch(error => {
                        console.error('Error sending email:', error);
                        const statusMessage = getSubmissionStatusMessage(firebaseSuccess, sheetsSuccess) + ', but failed to send email.';
                        sendResponse({ success: true, message: statusMessage });
                        chrome.tabs.sendMessage(sender.tab.id, { action: 'showStatus', text: statusMessage, type: 'error' });
                    });
                } else {
                    // Only Sheets succeeded
                    const statusMessage = getSubmissionStatusMessage(firebaseSuccess, sheetsSuccess);
                    sendResponse({ success: true, message: statusMessage });
                    chrome.tabs.sendMessage(sender.tab.id, { action: 'showStatus', text: statusMessage, type: 'success' });
                }
            } else {
                console.error('Both Firebase and Google Sheets submissions failed');
                sendResponse({ success: false, message: 'Failed to submit to both Firebase and Google Sheets.' });
                chrome.tabs.sendMessage(sender.tab.id, { action: 'showStatus', text: 'Failed to submit Link.', type: 'error' });
            }
        })
        .catch(error => {
            console.error('Error in parallel submissions:', error);
            sendResponse({ success: false, message: 'Failed to submit Link.' });
            chrome.tabs.sendMessage(sender.tab.id, { action: 'showStatus', text: 'Failed to submit Link.', type: 'error' });
        });
    })
    .catch(error => {
        console.error('Error fetching user info:', error);
        sendResponse({ success: false, message: 'Failed to retrieve user info.' });
        chrome.tabs.sendMessage(sender.tab.id, { action: 'showStatus', text: 'Failed to retrieve user info.', type: 'error' });
    });
}

// Trigger submission directly from the browser action (if needed)
chrome.action.onClicked.addListener((tab) => {
    const url = tab.url;

    // Authenticate and get user's email using OAuth2 for consistency
    chrome.identity.getAuthToken({ interactive: true }, function (token) {
        if (chrome.runtime.lastError || !token) {
            console.error('Authentication error:', chrome.runtime.lastError || 'No token retrieved');
            return;
        }

        // Get user info using OAuth2 token (consistent with main flow)
        fetch('https://www.googleapis.com/oauth2/v2/userinfo?alt=json', {
            headers: {
                'Authorization': 'Bearer ' + token
            }
        })
        .then(response => response.json())
        .then(userInfo => {
            const contact = userInfo?.email || '';

            if (!contact) {
                console.error('Contact (email) is missing');
                return;
            }

            // Submit to both Firebase and Google Sheets in parallel
            Promise.allSettled([
                // Firebase submission
                fetch('https://us-central1-sightonscene-a87ca.cloudfunctions.net/submitProperty', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + token
                    },
                    body: JSON.stringify({ url, contact })
                }).then(response => response.json()),
                
                // Google Sheets submission
                submitToGoogleSheets(url, contact, token)
            ])
            .then(results => {
                const [firebaseResult, sheetsResult] = results;
                
                console.log('Firebase result:', firebaseResult);
                console.log('Google Sheets result:', sheetsResult);
                
                const firebaseSuccess = firebaseResult.status === 'fulfilled';
                const sheetsSuccess = sheetsResult.status === 'fulfilled' && sheetsResult.value.success;
                
                if (firebaseSuccess || sheetsSuccess) {
                    console.log('Property submitted to at least one service via browser action');
                    
                    // Send usage email only if Firebase succeeded
                    if (firebaseSuccess) {
                        fetch('https://us-central1-sightonscene-a87ca.cloudfunctions.net/sendUsageEmails', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'Authorization': 'Bearer ' + token
                            },
                            body: JSON.stringify({ userEmail: contact, url })
                        })
                        .then(emailResponse => emailResponse.json())
                        .then(emailData => console.log('Email sent:', emailData))
                        .catch(error => console.error('Error sending email:', error));
                    }
                } else {
                    console.error('Both Firebase and Google Sheets submissions failed via browser action');
                }
            })
            .catch(error => {
                console.error('Error in parallel submissions via browser action:', error);
            });
        })
        .catch(error => {
            console.error('Error fetching user info via browser action:', error);
        });
    });
});
