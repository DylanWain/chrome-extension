console.log('🚀 Dibby Background Script Loaded');

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('📥 Background script received message:', message);
    console.log('📍 Message from tab:', sender.tab?.url || 'Unknown tab');
    
    if (message.action === 'activatePopup') {
        console.log('🔧 Opening popup programmatically');
        // Open the popup programmatically when the content script detects a matching URL
        chrome.action.openPopup();
        return false; // No response needed
    }

    if (message.action === 'submitProperty') {
        console.log('🏠 Starting property submission process');
        
        // Use the chrome.tabs API to get the active tab URL
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            console.log('🔍 Queried active tabs:', tabs.length);
            
            const activeTab = tabs[0];
            const url = activeTab?.url || '';
            console.log('📍 Active tab URL:', url);
            console.log('📍 Tab ID:', activeTab?.id);

            if (!url) {
                console.error('❌ URL is missing from active tab');
                sendResponse({ success: false, message: 'Failed to submit property: Missing URL.' });
                return;
            }

            console.log('🔐 Starting authentication process');
            // Authenticate and fetch user's email using OAuth2
            chrome.identity.getAuthToken({ interactive: true }, function (token) {
                if (chrome.runtime.lastError || !token) {
                    console.error('❌ Authentication error:', chrome.runtime.lastError || 'No token retrieved');
                    console.log('🔄 Attempting to refresh token...');
                    
                    // Remove cached token and retry authentication
                    chrome.identity.removeCachedAuthToken({ token }, function () {
                        console.log('🗑️ Cached token removed, retrying authentication');
                        
                        chrome.identity.getAuthToken({ interactive: true }, function (newToken) {
                            if (chrome.runtime.lastError || !newToken) {
                                console.error('❌ Authentication retry failed:', chrome.runtime.lastError || 'No token retrieved');
                                sendResponse({ success: false, message: 'Failed to authenticate user.' });
                                return;
                            }
                            console.log('✅ Token refreshed successfully');
                            token = newToken; // Use the refreshed token for the next steps
                            proceedWithPropertySubmission(url, token, sender, sendResponse);
                        });
                    });
                    return;
                }
                console.log('✅ Authentication successful, token obtained');
                console.log('🏠 Proceeding with property submission');
                proceedWithPropertySubmission(url, token, sender, sendResponse);
            });
        });
        
        return true; // Keep the message channel open for async response
    }
    
    return false; // No response needed for other messages
});

// Configuration - Replace with your actual Google Sheets ID
const GOOGLE_SHEETS_CONFIG = {
    spreadsheetId: '1baVsy9030NI12qzDes22gwWLjfzP7RA0dyrnNoGp1K0', // Replace with your Google Sheets ID
    range: 'Sheet1!A:C', // Adjust range as needed
    sheetName: 'Sheet1'
};

console.log('📊 Google Sheets configuration loaded:', GOOGLE_SHEETS_CONFIG);

// Google Sheets API integration
async function submitToGoogleSheets(url, contact, token) {
    console.log('📊 Starting Google Sheets submission');
    console.log('📊 Spreadsheet ID:', GOOGLE_SHEETS_CONFIG.spreadsheetId);
    console.log('📊 URL to submit:', url);
    console.log('📊 Contact:', contact);
    
    try {
        const timestamp = new Date().toISOString();
        console.log('🕒 Timestamp:', timestamp);
        
        // First, get the sheet to determine the next row
        console.log('📊 Getting current sheet data...');
        const getResponse = await fetch(
            `https://sheets.googleapis.com/v4/spreadsheets/${GOOGLE_SHEETS_CONFIG.spreadsheetId}/values/${GOOGLE_SHEETS_CONFIG.range}`,
            {
                headers: {
                    'Authorization': 'Bearer ' + token
                }
            }
        );
        
        console.log('📊 Get response status:', getResponse.status);
        
        if (!getResponse.ok) {
            throw new Error(`Failed to get sheet data: ${getResponse.status} ${getResponse.statusText}`);
        }
        
        const getResult = await getResponse.json();
        const nextRow = (getResult.values ? getResult.values.length : 0) + 1;
        console.log('📊 Next row to write:', nextRow);
        console.log('📊 Current sheet has', getResult.values?.length || 0, 'rows');
        
        // Append new row with property data
        const appendUrl = `https://sheets.googleapis.com/v4/spreadsheets/${GOOGLE_SHEETS_CONFIG.spreadsheetId}/values/${GOOGLE_SHEETS_CONFIG.sheetName}!A${nextRow}:C${nextRow}?valueInputOption=USER_ENTERED`;
        console.log('📊 Append URL:', appendUrl);
        
        const appendData = {
            values: [[timestamp, contact, url]]
        };
        console.log('📊 Data to append:', appendData);
        
        const appendResponse = await fetch(appendUrl, {
            method: 'PUT',
            headers: {
                'Authorization': 'Bearer ' + token,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(appendData)
        });
        
        console.log('📊 Append response status:', appendResponse.status);
        
        if (!appendResponse.ok) {
            const errorText = await appendResponse.text();
            console.error('📊 Sheets API error response:', errorText);
            throw new Error(`Sheets API error: ${appendResponse.status} - ${errorText}`);
        }
        
        const result = await appendResponse.json();
        console.log('✅ Successfully added to Google Sheets:', result);
        return { success: true, result };
        
    } catch (error) {
        console.error('❌ Error submitting to Google Sheets:', error);
        console.error('❌ Error stack:', error.stack);
        return { success: false, error: error.message };
    }
}

// Helper function to generate status messages based on submission results
function getSubmissionStatusMessage(firebaseSuccess, sheetsSuccess) {
    console.log('📊 Generating status message - Firebase:', firebaseSuccess, 'Sheets:', sheetsSuccess);
    
    if (firebaseSuccess && sheetsSuccess) {
        return 'Link submitted successfully to both Firebase and Google Sheets!';
    } else if (firebaseSuccess) {
        return 'Link submitted to Firebase successfully (Google Sheets failed)';
    } else if (sheetsSuccess) {
        return 'Link submitted to Google Sheets successfully (Firebase failed)';
    } else {
        return 'Failed to submit Link to both services';
    }
}

function proceedWithPropertySubmission(url, token, sender, sendResponse) {
    console.log('🏠 Proceeding with property submission');
    console.log('🏠 URL:', url);
    console.log('🏠 Sender tab ID:', sender.tab?.id);
    
    let responseSent = false; // Flag to prevent multiple responses
    
    const safeResponse = (response) => {
        if (!responseSent) {
            responseSent = true;
            console.log('📤 Sending response to content script:', response);
            sendResponse(response);
        } else {
            console.warn('⚠️ Attempted to send response multiple times, ignoring:', response);
        }
    };

    console.log('👤 Fetching user information...');
    fetch('https://www.googleapis.com/oauth2/v2/userinfo?alt=json', {
        headers: {
            'Authorization': 'Bearer ' + token
        }
    })
    .then(response => {
        console.log('👤 User info response status:', response.status);
        if (!response.ok) {
            throw new Error(`Failed to fetch user info: ${response.status}`);
        }
        return response.json();
    })
    .then(userInfo => {
        console.log('👤 User info received:', { email: userInfo?.email, name: userInfo?.name });
        const contact = userInfo?.email || '';

        if (!contact) {
            console.error('❌ Contact (email) is missing from user info');
            safeResponse({ success: false, message: 'Failed to submit property: Missing contact info.' });
            return;
        }

        console.log('🚀 Starting parallel submissions to Firebase and Google Sheets');
        
        // Submit to both Firebase and Google Sheets in parallel
        Promise.allSettled([
            // Firebase submission
            (async () => {
                console.log('🔥 Starting Firebase submission');
                try {
                    const firebaseResponse = await fetch('https://us-central1-sightonscene-a87ca.cloudfunctions.net/submitProperty', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': 'Bearer ' + token
                        },
                        body: JSON.stringify({ url, contact })
                    });
                    
                    console.log('🔥 Firebase response status:', firebaseResponse.status);
                    
                    if (!firebaseResponse.ok) {
                        throw new Error(`Firebase API error: ${firebaseResponse.status}`);
                    }
                    
                    const result = await firebaseResponse.json();
                    console.log('🔥 Firebase response data:', result);
                    return result;
                } catch (error) {
                    console.error('🔥 Firebase submission error:', error);
                    throw error;
                }
            })(),
            
            // Google Sheets submission
            submitToGoogleSheets(url, contact, token)
        ])
        .then(results => {
            const [firebaseResult, sheetsResult] = results;
            
            console.log('📊 All submissions completed');
            console.log('🔥 Firebase result:', firebaseResult);
            console.log('📊 Google Sheets result:', sheetsResult);
            
            // Check if at least one submission succeeded
            const firebaseSuccess = firebaseResult.status === 'fulfilled';
            const sheetsSuccess = sheetsResult.status === 'fulfilled' && sheetsResult.value.success;
            
            console.log('✅ Firebase success:', firebaseSuccess);
            console.log('✅ Sheets success:', sheetsSuccess);
            
            if (firebaseSuccess || sheetsSuccess) {
                console.log('✅ Property submitted to at least one service');
                
                // Send usage email only if Firebase succeeded (keeping original behavior)
                if (firebaseSuccess) {
                    console.log('📧 Sending usage email...');
                    fetch('https://us-central1-sightonscene-a87ca.cloudfunctions.net/sendUsageEmails', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': 'Bearer ' + token
                        },
                        body: JSON.stringify({ userEmail: contact, url })
                    })
                    .then(emailResponse => {
                        console.log('📧 Email response status:', emailResponse.status);
                        return emailResponse.json();
                    })
                    .then(emailData => {
                        console.log('✅ Email sent successfully:', emailData);
                        const statusMessage = getSubmissionStatusMessage(firebaseSuccess, sheetsSuccess);
                        safeResponse({ success: true, message: statusMessage });
                    })
                    .catch(error => {
                        console.error('❌ Error sending email:', error);
                        const statusMessage = getSubmissionStatusMessage(firebaseSuccess, sheetsSuccess) + ', but failed to send email.';
                        safeResponse({ success: true, message: statusMessage });
                    });
                } else {
                    // Only Sheets succeeded
                    console.log('📊 Only Google Sheets succeeded');
                    const statusMessage = getSubmissionStatusMessage(firebaseSuccess, sheetsSuccess);
                    safeResponse({ success: true, message: statusMessage });
                }
            } else {
                console.error('❌ Both Firebase and Google Sheets submissions failed');
                console.error('🔥 Firebase error:', firebaseResult.reason);
                console.error('📊 Sheets error:', sheetsResult.reason);
                safeResponse({ success: false, message: 'Failed to submit to both Firebase and Google Sheets.' });
            }
        })
        .catch(error => {
            console.error('❌ Error in parallel submissions:', error);
            console.error('❌ Error stack:', error.stack);
            safeResponse({ success: false, message: 'Failed to submit Link.' });
        });
    })
    .catch(error => {
        console.error('❌ Error fetching user info:', error);
        console.error('❌ Error stack:', error.stack);
        safeResponse({ success: false, message: 'Failed to retrieve user info.' });
    });
}

// Enhanced browser action listener with logging
chrome.action.onClicked.addListener((tab) => {
    console.log('🖱️ Browser action clicked');
    console.log('📍 Tab URL:', tab.url);
    console.log('📍 Tab ID:', tab.id);
    
    const url = tab.url;

    // Authenticate and get user's email using OAuth2 for consistency
    chrome.identity.getAuthToken({ interactive: true }, function (token) {
        if (chrome.runtime.lastError || !token) {
            console.error('❌ Authentication error in browser action:', chrome.runtime.lastError || 'No token retrieved');
            return;
        }

        console.log('✅ Authentication successful in browser action');
        
        // Get user info using OAuth2 token (consistent with main flow)
        fetch('https://www.googleapis.com/oauth2/v2/userinfo?alt=json', {
            headers: {
                'Authorization': 'Bearer ' + token
            }
        })
        .then(response => response.json())
        .then(userInfo => {
            console.log('👤 User info in browser action:', { email: userInfo?.email });
            const contact = userInfo?.email || '';

            if (!contact) {
                console.error('❌ Contact (email) is missing in browser action');
                return;
            }

            console.log('🚀 Starting parallel submissions via browser action');
            
            // Submit to both Firebase and Google Sheets in parallel
            Promise.allSettled([
                // Firebase submission
                fetch('https://us-central1-sightonscene-a87ca.cloudfunctions.net/submitProperty', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + token
                    },
                    body: JSON.stringify({ url, contact })
                }).then(response => response.json()),
                
                // Google Sheets submission
                submitToGoogleSheets(url, contact, token)
            ])
            .then(results => {
                const [firebaseResult, sheetsResult] = results;
                
                console.log('📊 Browser action submissions completed');
                console.log('🔥 Firebase result:', firebaseResult);
                console.log('📊 Google Sheets result:', sheetsResult);
                
                const firebaseSuccess = firebaseResult.status === 'fulfilled';
                const sheetsSuccess = sheetsResult.status === 'fulfilled' && sheetsResult.value.success;
                
                if (firebaseSuccess || sheetsSuccess) {
                    console.log('✅ Property submitted to at least one service via browser action');
                    
                    // Send usage email only if Firebase succeeded
                    if (firebaseSuccess) {
                        console.log('📧 Sending usage email via browser action');
                        fetch('https://us-central1-sightonscene-a87ca.cloudfunctions.net/sendUsageEmails', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'Authorization': 'Bearer ' + token
                            },
                            body: JSON.stringify({ userEmail: contact, url })
                        })
                        .then(emailResponse => emailResponse.json())
                        .then(emailData => console.log('✅ Email sent via browser action:', emailData))
                        .catch(error => console.error('❌ Error sending email via browser action:', error));
                    }
                } else {
                    console.error('❌ Both Firebase and Google Sheets submissions failed via browser action');
                }
            })
            .catch(error => {
                console.error('❌ Error in parallel submissions via browser action:', error);
            });
        })
        .catch(error => {
            console.error('❌ Error fetching user info via browser action:', error);
        });
    });
});

console.log('✅ Background script initialization complete');
