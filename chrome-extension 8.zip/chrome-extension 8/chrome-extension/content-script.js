console.log('Dibby Content Script Loaded.');

const allowedWebsites = [
    'facebook.com',
    'zillow.com',
    'apartments.com',
    'trulia.com',
    'craigslist.org',
    'furnishedfinder.com',
    'homes.com',
    'rent.com',
    'realtor.com',
    'streeteasy.com',
    'redfin.com',
    'hotpads.com',
    'apartmentfinder.com',
    // Car sales websites
    'autotrader.com',
    'cars.com',
    'cargurus.com',
    'kbb.com',
    'ebay.com',
    'carvana.com',
    // General marketplace/furniture websites
    'offerup.com',
    'nextdoor.com',
    'mercari.com',
    'aptdeco.com',
    '1stdibs.com'
];

// Enhanced URL checking with logging
const currentUrl = window.location.href;
const currentHostname = window.location.hostname;
console.log('Current URL:', currentUrl);
console.log('Current hostname:', currentHostname);

const matchedWebsite = allowedWebsites.find(website => currentUrl.includes(website));
console.log('Matched website:', matchedWebsite || 'None');

// Check if the URL matches the condition
if (allowedWebsites.some(website => window.location.href.includes(website))) {
    console.log('✅ URL matches allowed websites - Creating Dibby container');
    
    // Create a white box container for the icon
    const container = document.createElement('div');
    container.id = 'dibby-floating-container';
    container.style.position = 'fixed';
    container.style.zIndex = '99999';
    container.style.top = '80px';
    container.style.right = '0px';
    container.style.width = '120px'; //size of box
    container.style.height = '120px';
    container.style.backgroundColor = '#fff';
    container.style.border = '1px solid #ddd';
    container.style.borderRadius = '10px'; // Rounded corners for the white box
    container.style.boxShadow = '0 2px 5px rgba(0, 0, 0, 0.2)';
    container.style.display = 'flex';
    container.style.justifyContent = 'center';
    container.style.alignItems = 'center';
    container.style.cursor = 'pointer';
    container.style.isolation = 'isolate';
    container.style.backdropFilter = 'none';
    container.style.visibility = 'visible';
    container.style.opacity = '1';

    console.log('📦 Container created with styles applied');

    // Add the Dibby icon image inside the container
    const dibbyIcon = document.createElement('img');
    const iconUrl = chrome.runtime.getURL('dibby-icon.PNG');
    console.log('🖼️ Loading Dibby icon from:', iconUrl);
    
    dibbyIcon.src = iconUrl;
    dibbyIcon.alt = 'Dibby Icon';
    dibbyIcon.style.width = '88px'; //size of dibby dog
    dibbyIcon.style.height = '88px';

    // Add error handling for image loading
    dibbyIcon.onload = () => {
        console.log('✅ Dibby icon loaded successfully');
    };
    
    dibbyIcon.onerror = (error) => {
        console.error('❌ Failed to load Dibby icon:', error);
        console.error('Icon URL that failed:', iconUrl);
    };

    // Append the image to the container
    container.appendChild(dibbyIcon);

    // Append the container to the body of the webpage
    try {
        document.body.appendChild(container);
        console.log('✅ Dibby container successfully added to page');
    } catch (error) {
        console.error('❌ Failed to add container to page:', error);
    }

     // Add click event listener to the container
     container.addEventListener('click', () => {
        console.log('🖱️ Dibby icon clicked - Starting submission process');
        console.log('Current URL being submitted:', window.location.href);

        // Send message to background.js to submit the property and handle the response
        const messageData = { action: 'submitProperty' };
        console.log('📤 Sending message to background script:', messageData);
        
        chrome.runtime.sendMessage(messageData, (response) => {
            console.log('📥 Received response from background script:', response);
            
            // Add safety check for undefined response
            if (chrome.runtime.lastError) {
                console.error('❌ Runtime error occurred:', chrome.runtime.lastError);
                showStatus('Extension error occurred', 'error');
                return;
            }
            
            if (response && response.success) {
                console.log('✅ Submission successful:', response.message);
                showStatus(response.message, 'success'); // Show success message
            } else {
                console.log('❌ Submission failed:', response?.message || 'Unknown error');
                showStatus(response?.message || 'Unknown error occurred', 'error'); // Show error message
            }
        });
    });

    // Enhanced status function with logging
    function showStatus(message, type) {
        console.log(`📢 Showing status message: "${message}" (type: ${type})`);
        
        const statusDiv = document.createElement('div');
        statusDiv.textContent = message;
        statusDiv.style.position = 'fixed';
        statusDiv.style.top = '50%';
        statusDiv.style.left = '50%';
        statusDiv.style.padding = '10px';
        statusDiv.style.border = '1px solid #ddd';
        statusDiv.style.borderRadius = '5px';
        statusDiv.style.backgroundColor = type === 'error' ? 'red' : 'green';
        statusDiv.style.color = '#fff';
        statusDiv.style.zIndex = '10001';
        statusDiv.style.transform = 'translate(-50%, -50%)'; // Center the message
        
        try {
            document.body.appendChild(statusDiv);
            console.log('✅ Status message displayed successfully');
        } catch (error) {
            console.error('❌ Failed to display status message:', error);
        }

        // Hide the message after 3 seconds
        setTimeout(() => {
            try {
                statusDiv.remove();
                console.log('🗑️ Status message removed after 3 seconds');
            } catch (error) {
                console.error('❌ Failed to remove status message:', error);
            }
        }, 3000);
    }

    // Optional: Listen for messages to show status updates
    chrome.runtime.onMessage.addListener((message) => {
        console.log('📥 Content script received message:', message);
        
        if (message.action === 'showStatus') {
            console.log('📢 Showing status from background script');
            showStatus(message.text, message.type);
        }
    });
    
} else {
    console.log('❌ URL does not match allowed websites - Dibby container not created');
    console.log('Allowed websites:', allowedWebsites);
}
