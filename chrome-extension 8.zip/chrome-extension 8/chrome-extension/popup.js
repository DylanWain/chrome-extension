//this is what happens when the user actually clicks on the actual extension button, not on the Dibby dog icon that pops up on the
//page you are wanting it to show up on. This is for people who are actually using the extension button for when they are not
//on one of the host pages (zillow, rent.com, etc) so this will be for misc submissions but is still fully functional 

console.log('🎪 Popup.js loaded');

// Check if the submit button exists before adding event listener
const submitButton = document.getElementById('submitButton');
if (!submitButton) {
    console.error('❌ Submit button not found in popup HTML');
} else {
    console.log('✅ Submit button found, adding event listener');
    
    // Event listener for the button click
    submitButton.addEventListener('click', () => {
        console.log('🖱️ Submit button clicked in popup');

        // Get the active tab's URL
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            console.log('🔍 Queried active tabs from popup:', tabs.length);
            
            const activeTab = tabs[0];
            const url = activeTab?.url || '';
            console.log('📍 Active tab URL from popup:', url);

            // Check if URL is missing
            if (!url) {
                console.error('❌ URL is missing in popup');
                showStatus('Failed to submit property: Missing URL.', 'error');
                return;
            }

            console.log('🔐 Starting authentication in popup');
            // Authenticate and fetch user's email using OAuth2
            chrome.identity.getAuthToken({ interactive: true }, function (token) {
                if (chrome.runtime.lastError) {
                    console.error('❌ Authentication error in popup:', chrome.runtime.lastError);
                    showStatus('Failed to authenticate user.', 'error');
                    return;
                }

                console.log('✅ Authentication successful in popup');
                
                // Use the OAuth2 token to get the user's email
                fetch('https://www.googleapis.com/oauth2/v2/userinfo?alt=json', {
                    headers: {
                        'Authorization': 'Bearer ' + token
                    }
                })
                .then(response => {
                    console.log('👤 User info response status in popup:', response.status);
                    return response.json();
                })
                .then(userInfo => {
                    console.log('👤 User info received in popup:', { email: userInfo?.email });
                    const contact = userInfo?.email || '';

                    // Check if contact (email) is missing
                    if (!contact) {
                        console.error('❌ Contact (email) is missing in popup');
                        showStatus('Failed to submit property: Missing contact info.', 'error');
                        return;
                    }

                    console.log('👤 User email in popup:', contact);
                    console.log('🔥 Sending request to Firebase from popup');

                    // Send the URL and contact to Firebase function
                    fetch('https://us-central1-sightonscene-a87ca.cloudfunctions.net/submitProperty', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ url, contact })
                    })
                    .then(response => {
                        console.log('🔥 Firebase response status from popup:', response.status);
                        return response.json();
                    })
                    .then(data => {
                        console.log('✅ Response from Firebase function in popup:', data);
                        showStatus('Property submitted successfully!', 'success');
                    })
                    .catch(error => {
                        console.error('❌ Error submitting property in popup:', error);
                        console.error('❌ Error stack:', error.stack);
                        showStatus('Failed to submit property.', 'error');
                    });
                })
                .catch(error => {
                    console.error('❌ Error fetching user info in popup:', error);
                    console.error('❌ Error stack:', error.stack);
                    showStatus('Failed to retrieve user info.', 'error');
                });
            });
        });
    });
}

// Enhanced status function with logging
function showStatus(message, type) {
    console.log(`📢 Showing status in popup: "${message}" (type: ${type})`);
    
    const statusDiv = document.createElement('div');
    statusDiv.textContent = message;
    statusDiv.style.position = 'fixed';
    statusDiv.style.top = '150px';
    statusDiv.style.right = '20px';
    statusDiv.style.padding = '10px';
    statusDiv.style.border = '1px solid #ddd';
    statusDiv.style.borderRadius = '5px';
    statusDiv.style.backgroundColor = type === 'error' ? 'red' : 'green';
    statusDiv.style.color = '#fff';
    statusDiv.style.zIndex = '10001';
    
    try {
        document.body.appendChild(statusDiv);
        console.log('✅ Status message displayed in popup');
    } catch (error) {
        console.error('❌ Failed to display status message in popup:', error);
    }

    // Hide the message after 3 seconds
    setTimeout(() => {
        try {
            statusDiv.remove();
            console.log('🗑️ Status message removed from popup after 3 seconds');
        } catch (error) {
            console.error('❌ Failed to remove status message from popup:', error);
        }
    }, 3000);
}

console.log('✅ Popup script initialization complete');
